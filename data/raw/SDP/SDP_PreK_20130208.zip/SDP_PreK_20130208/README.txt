README.txt
This README file contains some background information and guidance on School District of Philadelphia data. All data is aggregated per school, and is given per school year (e.g. 2011-2012). This set of data was extracted on October 22, 2012 in coordination with State Reporting requirements. Due to other state and federal reporting requirements, much of this data is available from other sources. Typically each entity has their own requirements, and frequently refactor and aggregate data in different ways. Please keep this in mind if you compare this data with data derived from other sources. Most importantly, do not hesitate to contact us if you have any questions, or would like to request other data sets.
Happy data diving!
opendata@philasd.org

Notes on individual files:
SDP_PREK.CSV
Provides basic information on each pre-kindergarten school, including School_code (a unique identifier for each school).
SCHOOL_CODE - Unique identifier for each program; note that there may be several programs within a given school building (for example, Head Start).
SCHOOL_NAME_1 - Name of school.
SCHOOL_NAME_2 - Alternate name of school.
ADDRESS - Street address of school.
SCHOOL_ZIP - Zip code of school.
SCHOOL_ZIP_PLUS_4 - Zip+4 of school, often blank.
CITY - self explanatory.
STATE_CD - self explanatory.
PHONE_NUMBER - self explanatory.
SCH_START_GRADE - The lowest grade offered in the school; "PK" means Pre-kindergarden.
SCH_TERM_GRADE - The highest grade offered in the school.
HPADDR - Web site address for school. (Blank for Pre K)
SCHOOL_LEVEL_NAME - Type of School.
