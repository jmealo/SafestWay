README.txt
This README file contains some background information and guidance on School District of Philadelphia data. This catchment data was extracted on February 7, 2013; it represents the catchment areas for all School District schools for the 2012-13 school year. Due to other state and federal reporting requirements, much of this data is available from other sources. Typically each entity has their own requirements, and frequently refactor and aggregate data in different ways. Please keep this in mind if you compare this data with data derived from other sources. Most importantly, do not hesitate to contact us if you have any questions, or would like to request other data sets.
Happy data diving!
opendata@philasd.org

The catchment area data is provided in shapefile format, broken out by elementary, middle and high school.
Catchment_ES_2012-13 - Catchments for elementary schools.
Catchment_ES_2012-13 - Catchments for middle schools.
Catchment_ES_2012-13 - Catchments for high schools schools.


